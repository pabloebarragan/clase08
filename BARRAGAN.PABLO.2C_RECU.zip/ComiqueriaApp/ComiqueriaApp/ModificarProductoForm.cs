using ComiqueriaLogic;
using System;
using System.Windows.Forms;

namespace ComiqueriaApp
{
  public partial class ModificarProductoForm : Form
  {
    Comiqueria comiqueria;
    Producto producto;

    public ModificarProductoForm(Comiqueria c, Producto p )
    {
      InitializeComponent();
      this.comiqueria = c;
      this.producto = p;
    }

    private void btnCancelar_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void ModificarProductoForm_Load(object sender, EventArgs e)
    {
      lblDescripcion.Text = producto.Descripcion;
      txtPrecioActual.Text = ((decimal)producto.Precio).ToString();
    }

    private void btnModificar_Click(object sender, EventArgs e)
    {

    }
  }
}
