﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class Figura : Producto
    {
        //atributos:
        private double altura;

        //constructor:
        public Figura(int stock, double precio, double altura)
            : base(string.Format("Figura:{0}cm", altura), stock, precio)
        {
            this.altura = altura;
        }

        public Figura(string descripcion, int stock, double precio, double altura)
            : base(descripcion, stock, precio)
        {
            this.altura = altura;
        }

        //metodos:
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(base.ToString());
            sb.AppendFormat("Altura: {0}", this.altura);
            sb.AppendLine();
            return sb.ToString();
        }
    }
}
