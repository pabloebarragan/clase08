﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public sealed class Venta
    {
        //atributos:
        private DateTime fecha;
        private static int porcentajeIva;
        private double precioFinal;
        private Producto producto;

        //propiedades:
        public DateTime Fecha { get { return this.fecha; } }

        //constructor:
        static Venta()
        {
            porcentajeIva = 21;
        }

        public Venta(Producto producto, int cantidad)
        {
            this.producto = producto;
            Vender(cantidad);
        }

        //metodos:
        public static double CalcularPrecioFinal(double precioUnidad, int cantidad)
        {
            return precioUnidad * cantidad * ((porcentajeIva / 100) + 1);
        }

        public string ObtenerDescripcionBreve()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}{1}{2}", this.Fecha, this.producto.Descripcion, this.precioFinal.ToString("{0 }##.##"));
            return sb.ToString();
        }

        private void Vender(int cantidad)
        {
            this.producto.Stock -= cantidad;
            this.fecha = DateTime.Now;
            this.precioFinal = Venta.CalcularPrecioFinal(this.producto.Precio, cantidad);
        }
    }
}
