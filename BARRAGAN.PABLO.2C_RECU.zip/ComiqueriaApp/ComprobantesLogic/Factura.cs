using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComprobantesLogic
{
  class Factura : Comprobante
  {
    private DateTime fechaVencimiento;
    private TipoFactura tipoFactura;

    public enum TipoFactura
    {
      A,
      B,
      C,
      E
    }

   //constructor:
   public Factura(Venta venta, int diasParaVencimiento, TipoFactura tipofactura)
      : base(venta)
   {
      this.fechaVencimiento = DateTime.Now.AddDays(diasParaVencimiento);
      this.tipoFactura = tipofactura;
   }

    public Factura(Venta venta, TipoFactura tipofactura) : this(venta, 15, tipofactura)
    {
    }


    //metodos:
    public override string GenerarComprobante()
    {
      return "falta";
    }

    public override bool Equals(object obj)
    {
      bool retorno = false;
      if (obj is Factura)
        retorno = true;

      return retorno;
    }



  }
}
