﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public abstract class Producto
    {
        //Atributos:
        private Guid codigo;
        private string descripcion;
        private double precio;
        private int stock;

        //Propiedades:
        public string Descripcion
        {
            get
            {
                return this.descripcion;
            }
        }
        public double Precio
        {
            get
            {
                return this.precio;
            }
        }
        public int Stock
        {
            get
            {
                return this.stock;
            }
            set
            {
                if (value >= 0)
                    this.stock = value;
            }
        }

        //Constructores:
        protected Producto(string descripcion, int stock, double precio)
        {
            this.codigo = Guid.NewGuid();
            this.descripcion = descripcion;
            this.Stock = stock;
            this.precio = precio;
        }

        //Metodos:
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Descripcion: {0}", this.Descripcion);
            sb.AppendLine();
            sb.AppendFormat("Codigo: {0}", this.codigo.ToString());
            sb.AppendLine();
            sb.AppendFormat("Stock: {0}", this.Stock);
            sb.AppendLine();
            sb.AppendFormat("Precio: {0}", this.Precio);
            sb.AppendLine();

            return sb.ToString();
        }
        public static explicit operator Guid(Producto p)
        {
            return p.codigo;
        }
    }
}
