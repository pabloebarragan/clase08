﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class Comiqueria
    {
        //atributos:
        //------------------------------------------------------------------------------------------------------------------------
        private List<Producto> productos;
        private List<Venta> ventas;

        //propiedades:
        //------------------------------------------------------------------------------------------------------------------------
        public Producto this[Guid codigo]
        {
            get
            {
                foreach (Producto p in productos)
                {
                    if ((Guid)p == codigo)
                        return p;
                }
                return null;
            }
        }

        //constructor:
        //------------------------------------------------------------------------------------------------------------------------
        public Comiqueria()
        {
            productos = new List<Producto>();
            ventas = new List<Venta>();
        }

        //metodos:
        //------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Metodo para vender el producto del parametro
        /// </summary>
        /// <param name="producto"></param>
        public void Vender(Producto producto)
        {
            Vender(producto, 1);
        }

        /// <summary>
        /// Metodo para vender el producto del parametro, y las cantidades indicadas en el parametro tambien
        /// </summary>
        /// <param name="producto"></param>
        /// <param name="cantidad"></param>
        public void Vender(Producto producto, int cantidad)
        {
            Venta venta = new Venta(producto, cantidad);
            ventas.Add(venta);
        }
        //------------------------------------------------------------------------------------------------------------------------
        /// <summary>
        /// Almacena en un diccionario que devolverá los codigo de producto y descripcion
        /// </summary>
        /// <returns></returns>
        public Dictionary<Guid, string> ListarProductos()
        {
            Dictionary<Guid, string> dic = new Dictionary<Guid, string>();

            foreach (Producto p in productos)
            {
                dic.Add((Guid)p, p.Descripcion);
            }

            return dic;
        }
        /// <summary>
        /// Almacena en un string, que retornarà, una lista de descripciones de las ventas
        /// </summary>
        /// <returns></returns>
        public string ListarVentas()
        {
            StringBuilder sb = new StringBuilder();
            List<Venta> ventasOrdenadas = ObtenerVentasOrdenadas();
            foreach (Venta v in ventasOrdenadas)
            {
                sb.Append(v.ObtenerDescripcionBreve());
                sb.AppendLine();
            }
            return sb.ToString();
        }

        /// <summary>
        /// Almacena en una lista de ventas, retornandola luego de ordenarla
        /// </summary>
        /// <returns></returns>
        private List<Venta> ObtenerVentasOrdenadas()
        {
            return this.ventas.OrderBy(x => x.Fecha).ToList();
        }

        //Sobrecarga Operadores:
        //------------------------------------------------------------------------------------------------------------------------

        /// <summary>
        /// Operador distinto, en donde retorna true, si el producto no existe en la lista de productos de comiqueria
        /// </summary>
        /// <param name="comiqueria"></param>
        /// <param name="producto"></param>
        /// <returns></returns>
        public static bool operator !=(Comiqueria comiqueria, Producto producto)
        {
            return !(comiqueria == producto);
        }


        /// <summary>
        /// Operador igual, en donde retorna true, si el producto existe en la lista de productos de comiqueria
        /// </summary>
        /// <param name="comiqueria"></param>
        /// <param name="producto"></param>
        /// <returns></returns>
        public static bool operator ==(Comiqueria comiqueria, Producto producto)
        {
            foreach (Producto prod in comiqueria.productos)
            {
                if (producto.Descripcion == prod.Descripcion)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Operador sobrecargado para agregar en la lista de productos de comiqueria, el producto indicado
        /// </summary>
        /// <param name="comiqueria"></param>
        /// <param name="producto"></param>
        /// <returns></returns>
        public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
        {
            if (comiqueria != producto)
                comiqueria.productos.Add(producto);
            return comiqueria;
        }

    }
}
